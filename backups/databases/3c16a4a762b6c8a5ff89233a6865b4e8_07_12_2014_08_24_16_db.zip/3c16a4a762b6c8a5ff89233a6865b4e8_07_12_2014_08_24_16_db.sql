#
# TABLE STRUCTURE FOR: backup
#

DROP TABLE IF EXISTS backup;

CREATE TABLE `backup` (
  `backup_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `backup_name` varchar(255) NOT NULL,
  `backup_location` varchar(255) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`backup_id`),
  UNIQUE KEY `backup_name_UNIQUE` (`backup_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: ci_sessions
#

DROP TABLE IF EXISTS ci_sessions;

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) DEFAULT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('2291aa325dd0cd2d2bccd5fb93583150', '::1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:33.0) Gecko/20100101 Firefox/33.0', 1417934673, 'a:2:{s:9:\"user_data\";s:0:\"\";s:10:\"flexi_auth\";a:7:{s:15:\"user_identifier\";s:8:\"magister\";s:7:\"user_id\";s:1:\"4\";s:5:\"admin\";b:1;s:5:\"group\";a:1:{i:3;s:12:\"Master Admin\";}s:10:\"privileges\";a:11:{i:1;s:10:\"View Users\";i:2;s:16:\"View User Groups\";i:3;s:15:\"View Privileges\";i:4;s:18:\"Insert User Groups\";i:5;s:17:\"Insert Privileges\";i:6;s:12:\"Update Users\";i:7;s:18:\"Update User Groups\";i:8;s:17:\"Update Privileges\";i:9;s:12:\"Delete Users\";i:10;s:18:\"Delete User Groups\";i:11;s:17:\"Delete Privileges\";}s:22:\"logged_in_via_password\";b:1;s:19:\"login_session_token\";s:40:\"d2eb1bdd82f4f57cc4944ef715e199e15d9906b6\";}}');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('b2ed923915208531d90399e1d4e7dcca', '::1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:33.0) Gecko/20100101 Firefox/33.0', 1417937038, 'a:2:{s:9:\"user_data\";s:0:\"\";s:10:\"flexi_auth\";a:7:{s:15:\"user_identifier\";s:8:\"magister\";s:7:\"user_id\";s:1:\"4\";s:5:\"admin\";b:1;s:5:\"group\";a:1:{i:3;s:12:\"Master Admin\";}s:10:\"privileges\";a:11:{i:1;s:10:\"View Users\";i:2;s:16:\"View User Groups\";i:3;s:15:\"View Privileges\";i:4;s:18:\"Insert User Groups\";i:5;s:17:\"Insert Privileges\";i:6;s:12:\"Update Users\";i:7;s:18:\"Update User Groups\";i:8;s:17:\"Update Privileges\";i:9;s:12:\"Delete Users\";i:10;s:18:\"Delete User Groups\";i:11;s:17:\"Delete Privileges\";}s:22:\"logged_in_via_password\";b:1;s:19:\"login_session_token\";s:40:\"b7ca0f9b44e95b4817ef23fd1311a4f4b268e843\";}}');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('da65fd8d343448810535992e89c2cc93', '::1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:33.0) Gecko/20100101 Firefox/33.0', 1417937045, 'a:2:{s:9:\"user_data\";s:0:\"\";s:10:\"flexi_auth\";a:7:{s:15:\"user_identifier\";s:8:\"magister\";s:7:\"user_id\";s:1:\"4\";s:5:\"admin\";b:1;s:5:\"group\";a:1:{i:3;s:12:\"Master Admin\";}s:10:\"privileges\";a:11:{i:1;s:10:\"View Users\";i:2;s:16:\"View User Groups\";i:3;s:15:\"View Privileges\";i:4;s:18:\"Insert User Groups\";i:5;s:17:\"Insert Privileges\";i:6;s:12:\"Update Users\";i:7;s:18:\"Update User Groups\";i:8;s:17:\"Update Privileges\";i:9;s:12:\"Delete Users\";i:10;s:18:\"Delete User Groups\";i:11;s:17:\"Delete Privileges\";}s:22:\"logged_in_via_password\";b:1;s:19:\"login_session_token\";s:40:\"b50edf95b5f990d45b13d6fde8637a015efeb87d\";}}');


#
# TABLE STRUCTURE FOR: optimized
#

DROP TABLE IF EXISTS optimized;

CREATE TABLE `optimized` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO optimized (`id`, `modified_date`) VALUES (1, '2014-12-07 08:05:18');


#
# TABLE STRUCTURE FOR: user_accounts
#

DROP TABLE IF EXISTS user_accounts;

CREATE TABLE `user_accounts` (
  `uacc_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uacc_group_fk` smallint(5) unsigned NOT NULL DEFAULT '0',
  `uacc_email` varchar(100) NOT NULL DEFAULT '',
  `uacc_username` varchar(15) NOT NULL DEFAULT '',
  `uacc_password` varchar(60) NOT NULL DEFAULT '',
  `uacc_ip_address` varchar(40) NOT NULL DEFAULT '',
  `uacc_salt` varchar(40) NOT NULL DEFAULT '',
  `uacc_activation_token` varchar(40) NOT NULL DEFAULT '',
  `uacc_forgotten_password_token` varchar(40) NOT NULL DEFAULT '',
  `uacc_forgotten_password_expire` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `uacc_update_email_token` varchar(40) NOT NULL DEFAULT '',
  `uacc_update_email` varchar(100) NOT NULL DEFAULT '',
  `uacc_active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `uacc_suspend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `uacc_fail_login_attempts` smallint(5) NOT NULL DEFAULT '0',
  `uacc_fail_login_ip_address` varchar(40) NOT NULL DEFAULT '',
  `uacc_date_fail_login_ban` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Time user is banned until due to repeated failed logins',
  `uacc_date_last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `uacc_date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`uacc_id`),
  UNIQUE KEY `uacc_id` (`uacc_id`),
  KEY `uacc_group_fk` (`uacc_group_fk`),
  KEY `uacc_email` (`uacc_email`),
  KEY `uacc_username` (`uacc_username`),
  KEY `uacc_fail_login_ip_address` (`uacc_fail_login_ip_address`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO user_accounts (`uacc_id`, `uacc_group_fk`, `uacc_email`, `uacc_username`, `uacc_password`, `uacc_ip_address`, `uacc_salt`, `uacc_activation_token`, `uacc_forgotten_password_token`, `uacc_forgotten_password_expire`, `uacc_update_email_token`, `uacc_update_email`, `uacc_active`, `uacc_suspend`, `uacc_fail_login_attempts`, `uacc_fail_login_ip_address`, `uacc_date_fail_login_ban`, `uacc_date_last_login`, `uacc_date_added`) VALUES (4, 3, 'mamama@ammama.com', 'magister', '$2a$08$CiCF/UpA4migdWnBwuX2S.5W6qT343nOMPd/K3Fx3FM6d7zIJ3GTy', '::1', 'rgtCGbqwBnGDgdw3rSqCfr', '', '', '0000-00-00 00:00:00', '', '', 1, 0, 0, '', '0000-00-00 00:00:00', '2014-12-07 08:24:08', '2014-11-30 15:12:09');
INSERT INTO user_accounts (`uacc_id`, `uacc_group_fk`, `uacc_email`, `uacc_username`, `uacc_password`, `uacc_ip_address`, `uacc_salt`, `uacc_activation_token`, `uacc_forgotten_password_token`, `uacc_forgotten_password_expire`, `uacc_update_email_token`, `uacc_update_email`, `uacc_active`, `uacc_suspend`, `uacc_fail_login_attempts`, `uacc_fail_login_ip_address`, `uacc_date_fail_login_ban`, `uacc_date_last_login`, `uacc_date_added`) VALUES (7, 1, 'tarmizi.tajuddin@lada.gov.my', '1234567', '$2a$08$msZKxFUYrb/l8ePm641g4.kz8EV71Y2YGro7CrPb3HrA.hU39wTka', '::1', 'BJRpYxVyhCvWWCSXYcybY7', '5fb314e6b329739fb2ed95f85381acdc4c8168ea', '', '0000-00-00 00:00:00', '', '', 0, 0, 0, '', '0000-00-00 00:00:00', '2014-12-07 08:20:33', '2014-12-07 08:20:33');


#
# TABLE STRUCTURE FOR: user_groups
#

DROP TABLE IF EXISTS user_groups;

CREATE TABLE `user_groups` (
  `ugrp_id` smallint(5) NOT NULL AUTO_INCREMENT,
  `ugrp_name` varchar(20) NOT NULL DEFAULT '',
  `ugrp_desc` varchar(100) NOT NULL DEFAULT '',
  `ugrp_admin` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ugrp_id`),
  UNIQUE KEY `ugrp_id` (`ugrp_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO user_groups (`ugrp_id`, `ugrp_name`, `ugrp_desc`, `ugrp_admin`) VALUES (1, 'Public', 'Public User : has no admin access rights.', 0);
INSERT INTO user_groups (`ugrp_id`, `ugrp_name`, `ugrp_desc`, `ugrp_admin`) VALUES (2, 'Moderator', 'Admin Moderator : has partial admin access rights.', 1);
INSERT INTO user_groups (`ugrp_id`, `ugrp_name`, `ugrp_desc`, `ugrp_admin`) VALUES (3, 'Master Admin', 'Master Admin : has full admin access rights.', 1);


#
# TABLE STRUCTURE FOR: user_login_sessions
#

DROP TABLE IF EXISTS user_login_sessions;

CREATE TABLE `user_login_sessions` (
  `usess_uacc_fk` int(11) NOT NULL DEFAULT '0',
  `usess_series` varchar(40) NOT NULL DEFAULT '',
  `usess_token` varchar(40) NOT NULL DEFAULT '',
  `usess_login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`usess_token`),
  UNIQUE KEY `usess_token` (`usess_token`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO user_login_sessions (`usess_uacc_fk`, `usess_series`, `usess_token`, `usess_login_date`) VALUES (4, '', 'b50edf95b5f990d45b13d6fde8637a015efeb87d', '2014-12-07 08:24:16');
INSERT INTO user_login_sessions (`usess_uacc_fk`, `usess_series`, `usess_token`, `usess_login_date`) VALUES (4, '', 'b7ca0f9b44e95b4817ef23fd1311a4f4b268e843', '2014-12-07 08:24:01');


#
# TABLE STRUCTURE FOR: user_privilege_groups
#

DROP TABLE IF EXISTS user_privilege_groups;

CREATE TABLE `user_privilege_groups` (
  `upriv_groups_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `upriv_groups_ugrp_fk` smallint(5) unsigned NOT NULL DEFAULT '0',
  `upriv_groups_upriv_fk` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`upriv_groups_id`),
  UNIQUE KEY `upriv_groups_id` (`upriv_groups_id`) USING BTREE,
  KEY `upriv_groups_ugrp_fk` (`upriv_groups_ugrp_fk`),
  KEY `upriv_groups_upriv_fk` (`upriv_groups_upriv_fk`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

INSERT INTO user_privilege_groups (`upriv_groups_id`, `upriv_groups_ugrp_fk`, `upriv_groups_upriv_fk`) VALUES (1, 3, 1);
INSERT INTO user_privilege_groups (`upriv_groups_id`, `upriv_groups_ugrp_fk`, `upriv_groups_upriv_fk`) VALUES (3, 3, 3);
INSERT INTO user_privilege_groups (`upriv_groups_id`, `upriv_groups_ugrp_fk`, `upriv_groups_upriv_fk`) VALUES (4, 3, 4);
INSERT INTO user_privilege_groups (`upriv_groups_id`, `upriv_groups_ugrp_fk`, `upriv_groups_upriv_fk`) VALUES (5, 3, 5);
INSERT INTO user_privilege_groups (`upriv_groups_id`, `upriv_groups_ugrp_fk`, `upriv_groups_upriv_fk`) VALUES (6, 3, 6);
INSERT INTO user_privilege_groups (`upriv_groups_id`, `upriv_groups_ugrp_fk`, `upriv_groups_upriv_fk`) VALUES (7, 3, 7);
INSERT INTO user_privilege_groups (`upriv_groups_id`, `upriv_groups_ugrp_fk`, `upriv_groups_upriv_fk`) VALUES (8, 3, 8);
INSERT INTO user_privilege_groups (`upriv_groups_id`, `upriv_groups_ugrp_fk`, `upriv_groups_upriv_fk`) VALUES (9, 3, 9);
INSERT INTO user_privilege_groups (`upriv_groups_id`, `upriv_groups_ugrp_fk`, `upriv_groups_upriv_fk`) VALUES (10, 3, 10);
INSERT INTO user_privilege_groups (`upriv_groups_id`, `upriv_groups_ugrp_fk`, `upriv_groups_upriv_fk`) VALUES (11, 3, 11);
INSERT INTO user_privilege_groups (`upriv_groups_id`, `upriv_groups_ugrp_fk`, `upriv_groups_upriv_fk`) VALUES (12, 2, 2);
INSERT INTO user_privilege_groups (`upriv_groups_id`, `upriv_groups_ugrp_fk`, `upriv_groups_upriv_fk`) VALUES (13, 2, 4);
INSERT INTO user_privilege_groups (`upriv_groups_id`, `upriv_groups_ugrp_fk`, `upriv_groups_upriv_fk`) VALUES (14, 2, 5);
INSERT INTO user_privilege_groups (`upriv_groups_id`, `upriv_groups_ugrp_fk`, `upriv_groups_upriv_fk`) VALUES (16, 3, 2);


#
# TABLE STRUCTURE FOR: user_privilege_users
#

DROP TABLE IF EXISTS user_privilege_users;

CREATE TABLE `user_privilege_users` (
  `upriv_users_id` smallint(5) NOT NULL AUTO_INCREMENT,
  `upriv_users_uacc_fk` int(11) NOT NULL DEFAULT '0',
  `upriv_users_upriv_fk` smallint(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`upriv_users_id`),
  UNIQUE KEY `upriv_users_id` (`upriv_users_id`) USING BTREE,
  KEY `upriv_users_uacc_fk` (`upriv_users_uacc_fk`),
  KEY `upriv_users_upriv_fk` (`upriv_users_upriv_fk`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

INSERT INTO user_privilege_users (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES (1, 1, 1);
INSERT INTO user_privilege_users (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES (2, 1, 2);
INSERT INTO user_privilege_users (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES (3, 1, 3);
INSERT INTO user_privilege_users (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES (4, 1, 4);
INSERT INTO user_privilege_users (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES (5, 1, 5);
INSERT INTO user_privilege_users (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES (6, 1, 6);
INSERT INTO user_privilege_users (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES (7, 1, 7);
INSERT INTO user_privilege_users (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES (8, 1, 8);
INSERT INTO user_privilege_users (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES (9, 1, 9);
INSERT INTO user_privilege_users (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES (10, 1, 10);
INSERT INTO user_privilege_users (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES (11, 1, 11);
INSERT INTO user_privilege_users (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES (12, 2, 1);
INSERT INTO user_privilege_users (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES (13, 2, 2);
INSERT INTO user_privilege_users (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES (14, 2, 3);
INSERT INTO user_privilege_users (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES (15, 2, 6);
INSERT INTO user_privilege_users (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES (16, 4, 1);
INSERT INTO user_privilege_users (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES (17, 4, 2);
INSERT INTO user_privilege_users (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES (18, 4, 3);
INSERT INTO user_privilege_users (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES (19, 4, 4);
INSERT INTO user_privilege_users (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES (20, 4, 5);
INSERT INTO user_privilege_users (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES (21, 4, 6);
INSERT INTO user_privilege_users (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES (22, 4, 7);
INSERT INTO user_privilege_users (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES (23, 4, 8);
INSERT INTO user_privilege_users (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES (24, 4, 9);
INSERT INTO user_privilege_users (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES (25, 4, 10);
INSERT INTO user_privilege_users (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES (26, 4, 11);


#
# TABLE STRUCTURE FOR: user_privileges
#

DROP TABLE IF EXISTS user_privileges;

CREATE TABLE `user_privileges` (
  `upriv_id` smallint(5) NOT NULL AUTO_INCREMENT,
  `upriv_name` varchar(20) NOT NULL DEFAULT '',
  `upriv_desc` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`upriv_id`),
  UNIQUE KEY `upriv_id` (`upriv_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO user_privileges (`upriv_id`, `upriv_name`, `upriv_desc`) VALUES (1, 'View Users', 'User can view user account details.');
INSERT INTO user_privileges (`upriv_id`, `upriv_name`, `upriv_desc`) VALUES (2, 'View User Groups', 'User can view user groups.');
INSERT INTO user_privileges (`upriv_id`, `upriv_name`, `upriv_desc`) VALUES (3, 'View Privileges', 'User can view privileges.');
INSERT INTO user_privileges (`upriv_id`, `upriv_name`, `upriv_desc`) VALUES (4, 'Insert User Groups', 'User can insert new user groups.');
INSERT INTO user_privileges (`upriv_id`, `upriv_name`, `upriv_desc`) VALUES (5, 'Insert Privileges', 'User can insert privileges.');
INSERT INTO user_privileges (`upriv_id`, `upriv_name`, `upriv_desc`) VALUES (6, 'Update Users', 'User can update user account details.');
INSERT INTO user_privileges (`upriv_id`, `upriv_name`, `upriv_desc`) VALUES (7, 'Update User Groups', 'User can update user groups.');
INSERT INTO user_privileges (`upriv_id`, `upriv_name`, `upriv_desc`) VALUES (8, 'Update Privileges', 'User can update user privileges.');
INSERT INTO user_privileges (`upriv_id`, `upriv_name`, `upriv_desc`) VALUES (9, 'Delete Users', 'User can delete user accounts.');
INSERT INTO user_privileges (`upriv_id`, `upriv_name`, `upriv_desc`) VALUES (10, 'Delete User Groups', 'User can delete user groups.');
INSERT INTO user_privileges (`upriv_id`, `upriv_name`, `upriv_desc`) VALUES (11, 'Delete Privileges', 'User can delete user privileges.');


#
# TABLE STRUCTURE FOR: user_profiles
#

DROP TABLE IF EXISTS user_profiles;

CREATE TABLE `user_profiles` (
  `upro_id` int(11) NOT NULL AUTO_INCREMENT,
  `upro_uacc_fk` int(11) NOT NULL DEFAULT '0',
  `upro_company` varchar(50) NOT NULL DEFAULT '',
  `upro_first_name` varchar(50) NOT NULL DEFAULT '',
  `upro_last_name` varchar(50) NOT NULL DEFAULT '',
  `upro_phone` varchar(25) NOT NULL DEFAULT '',
  `upro_newsletter` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`upro_id`),
  UNIQUE KEY `upro_id` (`upro_id`),
  KEY `upro_uacc_fk` (`upro_uacc_fk`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO user_profiles (`upro_id`, `upro_uacc_fk`, `upro_company`, `upro_first_name`, `upro_last_name`, `upro_phone`, `upro_newsletter`) VALUES (4, 4, '', 'magister', 'magister', '423432', 0);
INSERT INTO user_profiles (`upro_id`, `upro_uacc_fk`, `upro_company`, `upro_first_name`, `upro_last_name`, `upro_phone`, `upro_newsletter`) VALUES (7, 7, '', 'kemat', 'hassan', '423234234', 0);


